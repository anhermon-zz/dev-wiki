module.exports = function() {
	var config = {
		PORT : 3001
	};
	return config;
}