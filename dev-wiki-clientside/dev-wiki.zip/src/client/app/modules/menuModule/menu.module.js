(function(angular) {
    'use strict';
    angular.module('angMenu', [
            'angCore'
    ]);
})(angular);
