(function(angular) {
    'use strict';
    angular.module('app', [
                    'angCore']);
})(angular);
